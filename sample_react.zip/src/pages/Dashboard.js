import React from 'react';

function Dashboard() {
    
}

export default Dashboard;